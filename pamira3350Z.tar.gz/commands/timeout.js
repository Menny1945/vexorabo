import { PermissionsBitField } from 'discord.js';

export default {
  name: 'timeout',
  description: 'Bir kullanıcıyı geçici olarak zaman aşımına alır.',
  async execute(message, args) {
    const user = message.mentions.users.first();
    const duration = parseInt(args[1]);

    if (!user || isNaN(duration)) {
      return message.reply('Geçerli bir kullanıcı ve süre belirtmelisiniz. Örnek: !timeout @kullanıcı 60');
    }

    const member = message.guild.members.cache.get(user.id);
    const botMember = message.guild.members.cache.get(message.client.user.id);

    if (!message.member.permissions.has(PermissionsBitField.Flags.ModerateMembers)) {
      return message.reply('Bu komutu kullanmak için yeterli izniniz yok.');
    }

    if (message.member.roles.highest.position <= member.roles.highest.position) {
      return message.reply('Bu kullanıcı sizin rolünüzden yüksek veya eşit bir role sahip. Onları zaman aşımına almanız mümkün değil.');
    }

    if (botMember.roles.highest.position <= member.roles.highest.position) {
      return message.reply('Botun rolü, bu kullanıcıdan daha düşük. Onlara zaman aşımı uygulamak mümkün değil.');
    }

    await member.timeout(duration * 1000, 'Geçici zaman aşımı');
    message.reply(`${user.tag} ${duration} saniye boyunca zaman aşımına alındı.`);
  },
};
