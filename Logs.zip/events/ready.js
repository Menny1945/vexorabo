import { Events } from 'discord.js';

// Durum mesajlarını tanımlayın
const statuses = [
  'PamiraDaSilva',
  'Yardım için .yardim yazın',
  'PamiraDaSilva',
  'Şu anda aktif!'
];

let index = 0;

export default {
  name: Events.ClientReady,
  once: true,
  async execute(client) {
    console.log(`Ready! Logged in as ${client.user.tag}`);

    // 15 saniyede bir durumu değiştir
    setInterval(() => {
      client.user.setPresence({
        activities: [{ name: statuses[index] }],
        status: 'dnd'
      });

      // Durumları döndür
      index = (index + 1) % statuses.length;
    }, 15000); // 15000 ms = 15 saniye
  },
};
