import db from 'croxydb';
import { EmbedBuilder } from 'discord.js';

function drawHangman(attempts) {
    const stages = [
        '```plaintext\n' +
        ' +---+\n' +
        ' |   |\n' +
        '     |\n' +
        '     |\n' +
        '     |\n' +
        '     |\n' +
        '=========\n```',

        '```plaintext\n' +
        ' +---+\n' +
        ' |   |\n' +
        ' O   |\n' +
        '     |\n' +
        '     |\n' +
        '     |\n' +
        '=========\n```',

        '```plaintext\n' +
        ' +---+\n' +
        ' |   |\n' +
        ' O   |\n' +
        ' |   |\n' +
        '     |\n' +
        '     |\n' +
        '=========\n```',

        '```plaintext\n' +
        ' +---+\n' +
        ' |   |\n' +
        ' O   |\n' +
        ' |   |\n' +
        ' /    |\n' +
        '     |\n' +
        '=========\n```',

        '```plaintext\n' +
        ' +---+\n' +
        ' |   |\n' +
        ' O   |\n' +
        ' |   |\n' +
        ' / \\  |\n' +
        '     |\n' +
        '=========\n```',

        '```plaintext\n' +
        ' +---+\n' +
        ' |   |\n' +
        ' O   |\n' +
        ' |   |\n' +
        ' / \\  |\n' +
        '     |\n' +
        '=========\n```',

        '```plaintext\n' +
        ' +---+\n' +
        ' |   |\n' +
        ' O   |\n' +
        ' |   |\n' +
        ' / \\  |\n' +
        '     |\n' +
        '=========\n```'
    ];

    return stages[6 - attempts];
}

export default {
    name: 'messageCreate',
    execute: async (message, client) => {
        if (!message.guild || message.author.bot) return;

        const prefix = client.config.prefix;

        // Komutları işleme
        if (message.content.startsWith(prefix)) {
            const args = message.content.slice(prefix.length).trim().split(/ +/);
            const commandName = args.shift().toLowerCase();

            const command = client.commands.get(commandName);
            if (!command) return;

            try {
                await command.execute(message, args);
            } catch (error) {
                console.error('Komut çalıştırılırken bir hata oluştu:', error);
                await message.reply('Bir hata oluştu!');
            }
        }

        // AFK durumunu kontrol etme
        const userAfkData = db.get(`afk_${message.author.id}`);
        if (userAfkData) {
            db.delete(`afk_${message.author.id}`);
            await message.reply('AFK modundan çıktınız.');
            return;
        }

        const mentionedUser = message.mentions.users.first();
        if (mentionedUser) {
            const afkData = db.get(`afk_${mentionedUser.id}`);
            if (afkData) {
                await message.reply(`${mentionedUser.username} şu anda AFK: ${afkData.reason} (AFK süresi: ${(Date.now() - afkData.time) / 1000} saniye)`);
            }
        }

        // Adamasmaca oyunu işlemleri
        const userId = message.author.id;
        const letter = message.content.toLowerCase();

        const game = db.get(`adamasmaca_${userId}`);
        if (game && letter.length === 1 && /^[a-z]$/i.test(letter)) {
            let { word, masked, attempts, guessedLetters } = game;

            if (guessedLetters.includes(letter)) {
                return message.reply('Bu harfi zaten tahmin ettiniz.');
            }

            guessedLetters.push(letter);

            if (word.includes(letter)) {
                masked = masked.split('').map((char, index) => word[index] === letter ? letter : char).join('');
                db.set(`adamasmaca_${userId}`, { word, masked, attempts, guessedLetters });

                if (masked === word) {
                    db.delete(`adamasmaca_${userId}`);
                    const winEmbed = new EmbedBuilder()
                        .setTitle('Tebrikler!')
                        .setDescription(`Kelimeyi doğru tahmin ettiniz: **${word}**`)
                        .setColor('#00ff00');
                    return message.reply({ embeds: [winEmbed] });
                }

                const correctGuessEmbed = new EmbedBuilder()
                    .setTitle('Doğru Tahmin!')
                    .setDescription(`Gizli kelime: **${masked}**`)
                    .setColor('#00ff00');
                return message.reply({ embeds: [correctGuessEmbed] });
            } else {
                attempts--;
                db.set(`adamasmaca_${userId}`, { word, masked, attempts, guessedLetters });

                if (attempts <= 0) {
                    db.delete(`adamasmaca_${userId}`);
                    const loseEmbed = new EmbedBuilder()
                        .setTitle('Oyunu Kaybettiniz!')
                        .setDescription(`Gizli kelime: **${word}**`)
                        .setColor('#ff0000');
                    return message.reply({ embeds: [loseEmbed] });
                }

                const hangmanEmbed = new EmbedBuilder()
                    .setTitle('Yanlış Tahmin!')
                    .setDescription(`${drawHangman(attempts)}\nKalan deneme sayınız: **${attempts}**\nGizli kelime: **${masked}**`)
                    .setColor('#ff0000');
                return message.reply({ embeds: [hangmanEmbed] });
            }
        }
    },
};
