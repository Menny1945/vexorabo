import { EmbedBuilder } from 'discord.js';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

// ES Modüllerinde __dirname'ı elde etmek için
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Yapılandırma dosyasını yükleyin
const config = JSON.parse(fs.readFileSync(path.join(__dirname, '../config.json'), 'utf-8'));

export default {
  name: 'restart',
  description: 'Botu yeniden başlatır.',
  async execute(message) {
    // Botun owner ID'sini kontrol et
    if (message.author.id !== config.ownerid) {
      return message.reply('Bu komutu sadece botun sahibi kullanabilir.');
    }

    // Embed mesaj oluştur
    const embed = new EmbedBuilder()
      .setColor('Green')
      .setTitle('Yeniden Başlatma')
      .setDescription('Bot yeniden başlatılıyor...');

    // Başlangıç mesajını gönder
    await message.reply({ embeds: [embed] });

    // Botu yeniden başlat
    process.exit();
  },
};
