import { getVoiceConnection } from '@discordjs/voice';
import fs from 'fs';
import path from 'path';

// JSON dosyasını oku
const configPath = path.resolve('config.json');
const config = JSON.parse(fs.readFileSync(configPath, 'utf-8'));

export default {
  name: 'sescik',
  description: 'Bot ses kanalından çıkar.',
  async execute(message) {
    if (message.author.id !== config.ownerid) {
      return message.reply('Bu komutu kullanma yetkiniz yok.');
    }

    const connection = getVoiceConnection(message.guild.id);

    if (!connection) {
      return message.reply('Bot şu anda herhangi bir ses kanalında değil.');
    }

    connection.destroy();
    await message.reply('Ses kanalından ayrıldım.');
  },
};
