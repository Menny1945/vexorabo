import { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } from 'discord.js';
import fs from 'fs/promises'; // fs/promises modülünü kullanarak JSON okuma
import path from 'path';

const configPath = path.resolve('./config.json'); // JSON dosyasının yolu

export default {
    name: 'interactionCreate',
    once: false,
    execute: async (interaction) => {
        if (!interaction.isButton()) return;

        // JSON dosyasını dinamik olarak yükle
        let config;
        try {
            const data = await fs.readFile(configPath, 'utf8');
            config = JSON.parse(data);
        } catch (error) {
            console.error('Config dosyası okunamadı:', error);
            return interaction.reply({ content: 'Konfigürasyon dosyası yüklenemedi.', ephemeral: true });
        }

        const userId = interaction.user.id;
        const customId = interaction.customId;

        if (customId === 'pesEt') {
            const game = db.get(`adamasmaca_${userId}`);
            if (!game) {
                return interaction.reply({ content: 'Aktif bir oyun bulunmuyor.', ephemeral: true });
            }

            db.delete(`adamasmaca_${userId}`);

            const embed = new EmbedBuilder()
                .setTitle('Oyun Sonlandırıldı')
                .setDescription('Oyunu pes ettiniz. Yeni bir oyun başlatabilirsiniz.')
                .setColor('#ff0000');

            return interaction.update({ embeds: [embed], components: [] });
        }

        // Kontrol: Kullanıcı geçerli değilse
        if (interaction.user.id !== config.ownerid) {
            return interaction.reply({ content: 'Bu butona tıklama yetkiniz yok.', ephemeral: true });
        }

        const embed = new EmbedBuilder().setColor('Random');

        switch (customId) {
            case 'moderasyon':
                embed
                    .setTitle('🔧 Moderasyon Komutları')
                    .setDescription('**.ban <kullanıcı> - Bir üyeyi yasaklar.\n.unban <kullanıcı> - Bir üyenin yasaklamasını kaldırır.\n.kick <kullanıcı> - Bir üyeyi atar.\n.hgbb <#kanal> - Katılan ve ayrılan üyeleri karşılar/veda eder.\n.rolver <@üye> <#rol> - Etiketlenen kişiye rol verir.\n.rolal <@üye> <#rol> - Etiketlenen kişiden rol alır.\n.sil <sayı> - Mesaj siler (max 500).\n.timeout <@üye> <süre> - Etiketlenen kişiye belirttiğin sürelik timeout atar.\n.untimeout <@üye> - Etiketlenen kişinin timeoutunu kaldırır.\n.slowmode <süre> - Yavaş mod ayarlar.**');
                break;
            case 'genel':
                embed
                    .setTitle('🌐 Genel Komutlar')
                    .setDescription('**.avatar <kullanıcı> - Avatarını gösterir.\n.banner <@üye> - Bannerını gösterir.\n.ping - Botun pingini gösterir.**');
                break;
            case 'bot':
                embed
                    .setTitle('🤖 Bot Komutları')
                    .setDescription('**.botinfo - Botun istatistiklerini gösterir.\n.ping - Botun pingini gösterir.\n.yardim - Yardım menüsünü gösterir.**');
                break;
            case 'owner':
                embed
                    .setTitle('👑 Owner Komutları')
                    .setDescription('**.ses-gir <#voice kanal> - Botu belirlenen ses kanalına sokar.\n.sescik - Botu olan sesten çıkarır.\n.restart - Botu yeniden başlatır.**');
                break;
            default:
                embed
                    .setTitle('Hatalı Buton')
                    .setDescription('Geçersiz bir butona tıkladınız.');
                break;
        }

        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('moderasyon')
                    .setLabel('🔧 Moderasyon')
                    .setStyle(ButtonStyle.Primary),
                new ButtonBuilder()
                    .setCustomId('genel')
                    .setLabel('🌐 Genel')
                    .setStyle(ButtonStyle.Primary),
                new ButtonBuilder()
                    .setCustomId('bot')
                    .setLabel('🤖 Bot')
                    .setStyle(ButtonStyle.Primary),
                new ButtonBuilder()
                    .setCustomId('owner')
                    .setLabel('👑 Owner')
                    .setStyle(ButtonStyle.Danger),
                new ButtonBuilder()
                    .setCustomId('pesEt')
                    .setLabel('Pes Et')
                    .setStyle(ButtonStyle.Secondary)
            );

        await interaction.update({
            embeds: [embed],
            components: [row],
        });

        // 60 saniye sonra butonları devre dışı bırak
        setTimeout(async () => {
            const disabledRow = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId('moderasyon')
                        .setLabel('🔧 Moderasyon')
                        .setStyle(ButtonStyle.Primary)
                        .setDisabled(true),
                    new ButtonBuilder()
                        .setCustomId('genel')
                        .setLabel('🌐 Genel')
                        .setStyle(ButtonStyle.Primary)
                        .setDisabled(true),
                    new ButtonBuilder()
                        .setCustomId('bot')
                        .setLabel('🤖 Bot')
                        .setStyle(ButtonStyle.Primary)
                        .setDisabled(true),
                    new ButtonBuilder()
                        .setCustomId('owner')
                        .setLabel('👑 Owner')
                        .setStyle(ButtonStyle.Danger)
                        .setDisabled(true),
                    new ButtonBuilder()
                        .setCustomId('pesEt')
                        .setLabel('Pes Et')
                        .setStyle(ButtonStyle.Secondary)
                        .setDisabled(true)
                );

            await interaction.editReply({
                components: [disabledRow],
            });
        }, 60000); // 60 saniye = 60000 milisaniye
    },
};
