import pkg from 'discord.js';
const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = pkg;

export default {
  name: 'yardim',
  description: 'Yardım menüsünü gösterir.',
  execute(message) {
    const embed = new EmbedBuilder()
      .setTitle('Yardım Menüsü')
      .setDescription('Aşağıdaki butonlardan birine tıklayarak yardım almak istediğiniz kategoriyi seçin.')
      .setColor('Random');

    const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('moderasyon')
          .setLabel('Moderasyon')
          .setStyle(ButtonStyle.Primary),
        new ButtonBuilder()
          .setCustomId('genel')
          .setLabel('Genel')
          .setStyle(ButtonStyle.Primary),
        new ButtonBuilder()
          .setCustomId('bot')
          .setLabel('Bot')
          .setStyle(ButtonStyle.Primary),
        new ButtonBuilder()
          .setCustomId('owner')
          .setLabel('Owner')
          .setStyle(ButtonStyle.Danger)
      );

    message.channel.send({
      embeds: [embed],
      components: [row],
    });
  },
};
