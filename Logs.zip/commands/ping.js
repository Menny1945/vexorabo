export default {
  name: 'ping',
  description: 'Ping komutu!',
  async execute(message, args) {
    const latency = Date.now() - message.createdTimestamp;
    await message.reply(`Pong! Gecikme: ${latency}ms`);
  },
};
