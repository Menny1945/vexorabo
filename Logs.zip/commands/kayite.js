import { PermissionsBitField } from 'discord.js';
import db from 'croxydb';

export default {
  name: 'kayite',
  description: 'Bir kullanıcıyı erkek olarak kaydeder.',
  async execute(message, args) {
    if (!message.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
      return message.reply('Bu komutu kullanmak için gerekli izinlere sahip değilsiniz.');
    }

    const kayitKanal = db.get(`kayitKanal_${message.guild.id}`);
    if (message.channel.id !== kayitKanal) {
      return message.reply('Kayıt işlemi sadece belirlenen kanalda yapılabilir.');
    }

    const yetkiliRol = db.get(`yetkiliRol_${message.guild.id}`);
    if (!message.member.roles.cache.has(yetkiliRol)) {
      return message.reply('Bu komutu kullanmak için gerekli yetkiye sahip değilsiniz.');
    }

    const uye = message.mentions.members.first();
    const erkekRol = db.get(`erkekRol_${message.guild.id}`);
    const kayitTag = db.get(`kayitTag_${message.guild.id}`) || '|';

    if (!uye) return message.reply('Kayıt etmek istediğiniz kullanıcıyı etiketleyin.');

    await uye.roles.add(erkekRol);
    await uye.setNickname(`${uye.user.username} ${kayitTag}`);

    message.reply(`${uye} başarıyla erkek olarak kayıt edildi.`);
  },
};
