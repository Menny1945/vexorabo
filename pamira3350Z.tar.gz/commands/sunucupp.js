import { EmbedBuilder } from 'discord.js';

export default {
    name: 'sunucupp',
    description: 'Sunucunun profil resmini gösterir.',
    execute: (message) => {
        const { guild } = message;
        const icon = guild.iconURL({ dynamic: true, size: 1024 });

        if (!icon) {
            return message.channel.send('Bu sunucunun profil resmi yok.');
        }

        const embed = new EmbedBuilder()
            .setTitle(`${guild.name} Sunucu Profil Resmi`)
            .setImage(icon)
            .setColor('Random')
            .setFooter({ text: `Sunucu ID: ${guild.id}` });

        message.channel.send({ embeds: [embed] });
    },
};
