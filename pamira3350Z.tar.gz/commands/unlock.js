import { PermissionsBitField } from 'discord.js';

export default {
    name: 'unlock',
    description: 'Kanalın kilidini açar ve herkesin mesaj atmasına izin verir.',
    execute: async (message, args) => {
        if (!message.member.permissions.has(PermissionsBitField.Flags.ManageChannels)) {
            return message.reply('Bu komutu kullanmak için **Kanalları Yönet** yetkisine sahip olmalısın.');
        }

        const channel = message.mentions.channels.first() || message.channel;

        try {
            await channel.permissionOverwrites.edit(message.guild.roles.everyone, {
                SendMessages: true,
            });

            await message.reply(`🔓 ${channel.name} kanalı başarıyla açıldı. Artık herkes mesaj atabilir.`);
        } catch (error) {
            console.error('Kanalı açma sırasında bir hata oluştu:', error);
            await message.reply('Kanalı açmaya çalışırken bir hata oluştu.');
        }
    },
};
