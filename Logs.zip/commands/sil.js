import { PermissionsBitField } from 'discord.js';

export default {
  name: 'sil',
  description: 'Belirtilen sayıda mesajı siler.',
  async execute(message, args) {
    if (!message.member.permissions.has(PermissionsBitField.Flags.ManageMessages)) {
      return message.reply('Bu komutu kullanmak için yeterli izne sahip değilsiniz.');
    }

    const amount = parseInt(args[0]);
    if (isNaN(amount) || amount < 1 || amount > 500) {
      return message.reply('Lütfen 1 ile 500 arasında bir sayı belirtin.');
    }

    async function deleteMessages(channel, amount) {
      let messagesToDelete = amount;
      while (messagesToDelete > 0) {
        const batchSize = Math.min(messagesToDelete, 100);
        const fetchedMessages = await channel.messages.fetch({ limit: batchSize });
        await channel.bulkDelete(fetchedMessages, true);
        messagesToDelete -= batchSize;
      }
    }

    try {
      await deleteMessages(message.channel, amount);
      const infoMessage = await message.channel.send(`${amount} mesaj başarıyla silindi.`);
      setTimeout(() => {
        infoMessage.delete().catch(console.error);
      }, 5000);
    } catch (error) {
      console.error(error);
      await message.reply('Mesajları silerken bir hata oluştu.');
    }
  },
};
