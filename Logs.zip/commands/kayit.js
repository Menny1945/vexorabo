import { PermissionsBitField, EmbedBuilder } from 'discord.js';
import db from 'croxydb';

export default {
  name: 'kayit',
  description: 'Kayıt sistemi ayarlarını yapar ve gösterir.',
  async execute(message, args) {
    if (!message.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
      return message.reply('Bu komutu kullanmak için gerekli izinlere sahip değilsiniz.');
    }

    const subCommand = args[0];
    const mention = message.mentions.roles.first() || message.mentions.channels.first();
    const tag = args.slice(1).join(' ');

    switch (subCommand) {
      case 'erkekrol':
        if (!mention) return message.reply('Bir rol belirtmelisiniz.');
        db.set(`erkekRol_${message.guild.id}`, mention.id);
        message.reply(`Erkek rolü ${mention} olarak ayarlandı.`);
        break;

      case 'kadinrol':
        if (!mention) return message.reply('Bir rol belirtmelisiniz.');
        db.set(`kadinRol_${message.guild.id}`, mention.id);
        message.reply(`Kadın rolü ${mention} olarak ayarlandı.`);
        break;

      case 'kanal':
        if (!mention) return message.reply('Bir kanal belirtmelisiniz.');
        db.set(`kayitKanal_${message.guild.id}`, mention.id);
        message.reply(`Kayıt kanalı ${mention} olarak ayarlandı.`);
        break;

      case 'yetkili':
        if (!mention) return message.reply('Bir rol belirtmelisiniz.');
        db.set(`yetkiliRol_${message.guild.id}`, mention.id);
        message.reply(`Yetkili rolü ${mention} olarak ayarlandı.`);
        break;

      case 'hosgeldinkanal':
        if (!mention) return message.reply('Bir kanal belirtmelisiniz.');
        db.set(`hosgeldinKanal_${message.guild.id}`, mention.id);
        message.reply(`Hoşgeldin kanalı ${mention} olarak ayarlandı.`);
        break;

      case 'tag':
        if (!tag) return message.reply('Bir tag belirtmelisiniz.');
        db.set(`kayitTag_${message.guild.id}`, tag);
        message.reply(`Tag "${tag}" olarak ayarlandı.`);
        break;

      default:
        const erkekRol = db.get(`erkekRol_${message.guild.id}`) 
          ? `<@&${db.get(`erkekRol_${message.guild.id}`)}>` 
          : 'Ayarlanmamış. Ayarlamak için: `.kayit erkekrol @rol`';
          
        const kadinRol = db.get(`kadinRol_${message.guild.id}`) 
          ? `<@&${db.get(`kadinRol_${message.guild.id}`)}>` 
          : 'Ayarlanmamış. Ayarlamak için: `.kayit kadinrol @rol`';
          
        const kayitKanal = db.get(`kayitKanal_${message.guild.id}`) 
          ? `<#${db.get(`kayitKanal_${message.guild.id}`)}>` 
          : 'Ayarlanmamış. Ayarlamak için: `.kayit kanal #kanal`';
          
        const yetkiliRol = db.get(`yetkiliRol_${message.guild.id}`) 
          ? `<@&${db.get(`yetkiliRol_${message.guild.id}`)}>` 
          : 'Ayarlanmamış. Ayarlamak için: `.kayit yetkili @rol`';
          
        const hosgeldinKanal = db.get(`hosgeldinKanal_${message.guild.id}`) 
          ? `<#${db.get(`hosgeldinKanal_${message.guild.id}`)}>` 
          : 'Ayarlanmamış. Ayarlamak için: `.kayit hosgeldinkanal #kanal`';
          
        const kayitTag = db.get(`kayitTag_${message.guild.id}`) 
          ? db.get(`kayitTag_${message.guild.id}`) 
          : 'Ayarlanmamış. Ayarlamak için: `.kayit tag sembol`';

        const embed = new EmbedBuilder()
          .setTitle(`${message.guild.name} - Kayıt Sistemi Ayarları`)
          .setColor(0x00AE86)
          .addFields(
            { name: 'Erkek Rolü', value: erkekRol, inline: true },
            { name: 'Kadın Rolü', value: kadinRol, inline: true },
            { name: 'Kayıt Kanalı', value: kayitKanal, inline: true },
            { name: 'Yetkili Rolü', value: yetkiliRol, inline: true },
            { name: 'Hoşgeldin Kanalı', value: hosgeldinKanal, inline: true },
            { name: 'Tag', value: kayitTag, inline: true }
          )
          .setTimestamp();

        message.channel.send({ embeds: [embed] });
        break;
    }
  },
};
