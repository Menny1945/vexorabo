import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { Client, GatewayIntentBits, Collection } from 'discord.js';
import dotenv from 'dotenv';

// ES Modüllerinde __dirname'ı elde etmek için
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// .env dosyasını yükleyin
dotenv.config();

// Discord.js Client'ı oluşturun
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildPresences,
    GatewayIntentBits.MessageContent,
  ],
});

// Komutları yüklemek için bir Collection oluşturun
client.commands = new Collection();

// Yapılandırma dosyasını yükleyin
const configPath = path.join(__dirname, 'config.json');
if (fs.existsSync(configPath)) {
  client.config = JSON.parse(fs.readFileSync(configPath, 'utf-8'));
} else {
  console.error(`Config dosyası bulunamadı: ${configPath}`);
  process.exit(1);
}

// Komut dosyalarını ve olay dosyalarını yüklemek için async IIFE (Immediately Invoked Function Expression) kullanın
(async () => {
  try {
    // Komut dosyalarını yükleyin
    const commandFiles = fs.readdirSync(path.join(__dirname, 'commands')).filter(file => file.endsWith('.js'));
    console.log('Yüklenen komutlar:');
    for (const file of commandFiles) {
      const { default: command } = await import(path.join(__dirname, 'commands', file));
      client.commands.set(command.name, command);
      console.log(`- ${command.name}`);
    }

    // Olay dosyalarını yükleyin
    const eventFiles = fs.readdirSync(path.join(__dirname, 'events')).filter(file => file.endsWith('.js'));
    console.log('Yüklenen olaylar:');
    for (const file of eventFiles) {
      const { default: event } = await import(path.join(__dirname, 'events', file));
      if (event.once) {
        client.once(event.name, (...args) => event.execute(...args, client));
      } else {
        client.on(event.name, (...args) => event.execute(...args, client));
      }
      console.log(`- ${event.name}`);
    }

    client.once('ready', () => {
      console.log(`${client.user.tag} is online!`);
    });

    // Botu başlat
    await client.login(process.env.TOKEN);
  } catch (error) {
    console.error('Bot başlatılırken bir hata oluştu:', error);
  }
})();
