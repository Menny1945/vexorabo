import { EmbedBuilder } from 'discord.js';

export default {
    name: 'serverinfo',
    description: 'Sunucu bilgilerini gösterir.',
    async execute(message) {
        const guild = message.guild;
        const memberCount = guild.memberCount;
        const onlineMembers = guild.members.cache.filter(member => member.presence?.status === 'online').size;
        const totalChannels = guild.channels.cache.size;
        const textChannels = guild.channels.cache.filter(c => c.type === 'GUILD_TEXT').size;
        const voiceChannels = guild.channels.cache.filter(c => c.type === 'GUILD_VOICE').size;
        const rolesCount = guild.roles.cache.size;
        const createdAt = guild.createdAt.toDateString();

        // Sunucu bilgilerini içeren embed oluşturun
        const embed = new EmbedBuilder()
            .setColor('#7289DA') // Discord mavi rengi
            .setTitle(`${guild.name} Sunucu Bilgileri`)
            .setThumbnail(guild.iconURL()) // Sunucu simgesi
            .addFields(
                { name: '🏷️ Sunucu Adı', value: guild.name, inline: true },
                { name: '🌍 Bölge', value: guild.preferredLocale, inline: true },
                { name: '🆔 Sunucu ID', value: guild.id, inline: true },
                { name: '👥 Toplam Üye', value: `${memberCount} üye`, inline: true },
                { name: '💬 Metin Kanalları', value: `${textChannels} kanal`, inline: true },
                { name: '🔊 Ses Kanalları', value: `${voiceChannels} kanal`, inline: true },
                { name: '🛠️ Roller', value: `${rolesCount} rol`, inline: true },
                { name: '📅 Oluşturulma Tarihi', value: createdAt, inline: true },
                { name: '🟢 Çevrim İçi Üyeler', value: `${onlineMembers} üye`, inline: true }
            )
            .setFooter({ text: `Bilgi istendi` })
            .setTimestamp();

        // Mesajı yanıtla
        await message.channel.send({ embeds: [embed] });
    }
};
