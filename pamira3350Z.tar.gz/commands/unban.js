import { PermissionsBitField } from 'discord.js';

export default {
  name: 'unban',
  description: 'Belirtilen kullanıcının yasağını kaldırır.',
  async execute(message, args) {
    if (!message.member.permissions.has(PermissionsBitField.Flags.BanMembers)) {
      return message.reply('Bu komutu kullanmak için yeterli yetkiye sahip değilsiniz.');
    }

    const userId = args[0];
    if (!userId) {
      return message.reply('Lütfen yasağını kaldırmak için bir kullanıcı ID\'si belirtin.');
    }

    try {
      await message.guild.members.unban(userId);
      await message.reply('Kullanıcının yasağı başarıyla kaldırıldı.');
    } catch (error) {
      console.error(error);
      await message.reply('Kullanıcının yasağını kaldırırken bir hata oluştu. Kullanıcı ID\'sini kontrol edin ve kullanıcının gerçekten yasaklı olduğundan emin olun.');
    }
  },
};
