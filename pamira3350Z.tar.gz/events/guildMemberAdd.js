import { PermissionsBitField, EmbedBuilder } from 'discord.js';
import db from 'croxydb';
import fetch from 'node-fetch';
import Canvas from 'canvas';
import fs from 'fs';
import path from 'path';
import sharp from 'sharp';

const __dirname = new URL('.', import.meta.url).pathname;

export default {
  name: 'guildMemberAdd',
  async execute(member) {
    console.log(`${member.user.tag} sunucuya katıldı.`);

    const logChannelId = db.get(`logChannel_${member.guild.id}`);
    const hosgeldinKanal = member.guild.channels.cache.get(db.get(`hosgeldinKanal_${member.guild.id}`));
    const yetkiliRol = db.get(`yetkiliRol_${member.guild.id}`);

    if (!logChannelId) {
      console.log('Log kanalı ayarlanmamış.');
      return;
    }

    const channel = member.guild.channels.cache.get(logChannelId);
    if (!channel) {
      console.log('Log kanalı bulunamadı.');
      return;
    }

    try {
      // Avatar URL'sini al
      const avatarURL = member.user.displayAvatarURL({ format: 'png', size: 1024 });

      // Avatarı yükle ve PNG formatına dönüştür
      const responseAvatar = await fetch(avatarURL);
      const arrayBufferAvatar = await responseAvatar.arrayBuffer();
      const bufferAvatar = Buffer.from(arrayBufferAvatar);
      const pngBufferAvatar = await sharp(bufferAvatar).toFormat('png').toBuffer();

      // Yerel dosya yolu
      const imagePath = path.join(__dirname, '../selam.png');
      const localImageBuffer = fs.readFileSync(imagePath);

      // Canvas oluştur
      const canvas = Canvas.createCanvas(1470, 824);
      const ctx = canvas.getContext('2d');

      // Arka plan görselini yükle
      const background = await Canvas.loadImage(localImageBuffer);
      ctx.drawImage(background, 0, 0, canvas.width, canvas.height);

      // Avatarı çiz
      const avatar = await Canvas.loadImage(pngBufferAvatar);
      const avatarSize = 320; // Avatarı büyüt
      const avatarX = (canvas.width - avatarSize) / 2; // Avatarı ortala
      const avatarY = (canvas.height - avatarSize) / 2 - 50; // Avatarı yukarı kaydır

      // Daire şeklinde klip oluştur
      ctx.save();
      ctx.beginPath();
      ctx.arc(canvas.width / 2, canvas.height / 2 - 50, avatarSize / 2, 0, Math.PI * 2, true); // Daire şekli
      ctx.closePath();
      ctx.clip();
      ctx.drawImage(avatar, avatarX, avatarY, avatarSize, avatarSize);
      ctx.restore();

      // Metin ekle
      ctx.font = '80px "Roboto Slab", serif'; // Daha büyük "Hoşgeldin" yazısı
      ctx.fillStyle = '#ffffff';
      ctx.textAlign = 'center';
      ctx.fillText('Hoşgeldin', canvas.width / 2, 120); // "Hoşgeldin" metnini yukarıda göster

      ctx.font = '60px "Roboto", sans-serif'; // Daha büyük isim yazısı
      ctx.fillText(`${member.user.tag}`, canvas.width / 2, 600); // İsim metnini daha aşağıda göster

      const attachment = new AttachmentBuilder(canvas.toBuffer(), { name: 'welcome-image.png' });
      await channel.send({ content: `Hoşgeldin ${member.user}`, files: [attachment] });
    } catch (error) {
      console.error('Resim işlenirken bir hata oluştu:', error);
    }

    // Hoş geldin mesajı ve yetkiliyi etiketleme
    if (hosgeldinKanal) {
      hosgeldinKanal.send(`Hoşgeldin ${member}! Lütfen biraz bekle, <@&${yetkiliRol}> seni kayıt edecektir.`);
    } else {
      console.log('Hoşgeldin kanalı ayarlanmamış.');
    }
  },
};
