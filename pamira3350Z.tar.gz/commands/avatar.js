import { EmbedBuilder } from 'discord.js';

export default {
  name: 'avatar',
  description: 'Belirtilen kullanıcının avatarını gösterir.',
  async execute(message, args) {
    const user = message.mentions.users.first() || message.author;

    const embed = new EmbedBuilder()
      .setTitle(`${user.tag} kullanıcısının avatarı`)
      .setImage(user.displayAvatarURL({ dynamic: true, size: 512 }))
      .setColor('#0099ff');

    await message.reply({ embeds: [embed] });
  },
};
