import db from 'croxydb';

export default {
    name: 'afk',
    description: 'AFK moduna geçer ve belirtilen mesajı bırakır.',
    execute: async (message, args) => {
        // Kullanıcının AFK durumunu kontrol et
        const isAfk = db.get(`afk_${message.author.id}`);
        if (isAfk) {
            // Kullanıcı zaten AFK'da, AFK'dan çıkma işlemini yap
            db.delete(`afk_${message.author.id}`);
            db.delete(`afk_${message.author.id}_pending`);
            return message.reply('AFK modundan çıktınız.');
        }

        const afkReason = args.join(' ') || 'Şu anda AFK.';

        // Kullanıcının AFK durumunu ve mesajını veritabanına kaydet
        db.set(`afk_${message.author.id}_reason`, afkReason);
        db.set(`afk_${message.author.id}_time`, Date.now());

        // 20 saniye boyunca kullanıcıya mesaj yazma izni ver
        db.set(`afk_${message.author.id}_pending`, true);

        // 20 saniye sonra kullanıcıyı AFK moduna al
        setTimeout(async () => {
            const pending = db.get(`afk_${message.author.id}_pending`);
            if (pending) {
                db.delete(`afk_${message.author.id}_pending`);
                db.set(`afk_${message.author.id}`, {
                    reason: afkReason,
                    time: Date.now(),
                });
                await message.reply('20 saniyelik süre doldu, artık AFK modundasınız.');
            }
        }, 20000); // 20 saniye

        try {
            await message.reply(`AFK moduna geçiş için 20 saniye verildi. Sebep: ${afkReason}`);
        } catch (error) {
            console.error('AFK moduna geçerken bir hata oluştu:', error);
            await message.reply('AFK moduna geçmeye çalışırken bir hata oluştu.');
        }
    },
};
