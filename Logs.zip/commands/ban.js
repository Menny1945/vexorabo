import { PermissionsBitField } from 'discord.js';

export default {
  name: 'ban',
  description: 'Belirtilen kullanıcıyı sunucudan yasaklar.',
  async execute(message, args) {
    // Sunucunun sahibi kontrolü
    const isServerOwner = message.guild.ownerId === message.author.id;

    // Yetki kontrolü
    if (!isServerOwner && !message.member.permissions.has(PermissionsBitField.Flags.BanMembers)) {
      return message.reply('Bu komutu kullanmak için yeterli yetkiye sahip değilsiniz.');
    }

    const user = message.mentions.users.first();
    if (!user) {
      return message.reply('Lütfen yasaklamak için bir kullanıcı belirtin.');
    }

    const member = message.guild.members.cache.get(user.id);
    if (!member) {
      return message.reply('Bu kullanıcı sunucuda bulunmuyor.');
    }

    // Yetki kontrolü
    if (!isServerOwner) {
      if (member.roles.highest.position >= message.member.roles.highest.position) {
        return message.reply('Kendinizden üstteki birini yasaklayamazsınız.');
      }

      if (member.roles.highest.position >= message.guild.members.me.roles.highest.position) {
        return message.reply('Bu kullanıcıyı yasaklayamam çünkü onun rolü benim rolümden üstün.');
      }
    }

    const reason = args.slice(1).join(' ') || 'Neden belirtilmemiş';

    try {
      await member.ban({ reason });
      
      // Yasaklanan kullanıcıya DM gönder
      try {
        await user.send(`Merhaba, ${message.guild.name} sunucusundan yasaklandınız.\nSebep: ${reason}`);
      } catch (dmError) {
        console.error('DM gönderilirken bir hata oluştu:', dmError);
      }

      await message.reply(`${user.tag} başarıyla yasaklandı. Sebep: ${reason}`);
    } catch (error) {
      console.error(error);
      await message.reply('Kullanıcıyı yasaklarken bir hata oluştu.');
    }
  },
};
