import { ShardingManager } from 'discord.js';
import { sendWebhookMessage } from './helpers/webhook.js'; // `.js` uzantısını unutmayın
import dotenv from 'dotenv';

dotenv.config();

const manager = new ShardingManager('./index.js', {
  totalShards: 2,
  token: process.env.TOKEN,
});

manager.on('shardCreate', shard => {
  console.log(`Shard ${shard.id} başlatıldı.`);

  shard.on('ready', () => {
    sendWebhookMessage(`Sunucu ${shard.id} aktif.`);
  });

  shard.on('disconnect', () => {
    sendWebhookMessage(`Sunucu ${shard.id} bağlantısı kesildi.`);
  });

  shard.on('reconnecting', () => {
    sendWebhookMessage(`Sunucu ${shard.id} düştü, tekrar bağlanılmaya çalışılıyor.`);
  });

  shard.on('death', () => {
    sendWebhookMessage(`Sunucu ${shard.id} kritik bir hata ile karşılaştı.`);
  });
});

manager.spawn();
