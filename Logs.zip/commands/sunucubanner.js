import { EmbedBuilder } from 'discord.js';

export default {
    name: 'sunucubanner',
    description: 'Sunucunun banner resmini gösterir.',
    execute: async (message) => {
        const { guild } = message;
        const banner = guild.bannerURL({ dynamic: true, size: 1024 });

        if (!banner) {
            return message.channel.send('Bu sunucunun banner resmi yok.');
        }

        const embed = new EmbedBuilder()
            .setTitle(`${guild.name} Sunucu Banner Resmi`)
            .setImage(banner)
            .setColor('Random')
            .setFooter({ text: `Sunucu ID: ${guild.id}` });

        message.channel.send({ embeds: [embed] });
    },
};
