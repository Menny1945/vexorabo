import { PermissionsBitField, EmbedBuilder } from 'discord.js';

export default {
    name: 'nuke',
    description: 'Kanalı siler ve aynı izinlerle, aynı kategoride yeni bir kanal oluşturur.',
    async execute(message) {
        if (!message.member.permissions.has(PermissionsBitField.Flags.ManageChannels)) {
            return message.reply("Bu komutu kullanmak için yeterli izniniz yok.");
        }

        const channel = message.channel;

        try {
            // Kanal bilgilerini saklayın
            const channelName = channel.name;
            const parent = channel.parent; // Aynı kategori
            const position = channel.position; // Aynı sırada
            const permissionOverwrites = channel.permissionOverwrites.cache; // Aynı izinler

            // Kanalı sil
            await channel.delete();

            // Yeni kanal oluştur
            const newChannel = await message.guild.channels.create({
                name: channelName,
                type: channel.type,
                parent: parent, // Aynı kategori
                position: position, // Aynı sırada
                permissionOverwrites: permissionOverwrites // Aynı izinler
            });

            // Embed mesaj oluştur
            const embed = new EmbedBuilder()
                .setColor('#00FF00') // Renk kodunu ihtiyacınıza göre değiştirebilirsiniz
                .setTitle('Kanal Nuke Edildi!')
                .setDescription(`Kanal **${channelName}** başarılı bir şekilde nuke edildi ve **${newChannel.name}** olarak yeniden oluşturuldu.`)
                .setTimestamp()
                .setFooter({ text: 'Botunuzun adı' }); // Bot adınızı buraya ekleyebilirsiniz

            // Yeni kanalda embed mesajı gönder
            await newChannel.send({ embeds: [embed] });

            // Bilgilendirme mesajını kanalda değil, kullanıcıya doğrudan gönder
            await message.author.send(`Kanal başarılı bir şekilde nuke edildi ve **${newChannel.name}** olarak yeniden oluşturuldu.`);
        } catch (error) {
            console.error('Kanal nuke işlemi sırasında bir hata oluştu:', error);
            // Hata durumunda kullanıcıya doğrudan bilgi ver
            await message.author.send('Kanal nuke işlemi sırasında bir hata oluştu.');
        }
    }
};
