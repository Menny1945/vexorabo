import { EmbedBuilder } from 'discord.js';

export default {
  name: 'banner',
  description: 'Belirtilen kullanıcının bannerını gösterir.',
  async execute(message, args) {
    const user = message.mentions.users.first() || message.author;
    const member = await message.guild.members.fetch(user.id);

    const banner = await member.user.fetch().then(u => u.bannerURL({ dynamic: true, size: 512 }));

    if (!banner) {
      return message.reply('Bu kullanıcının bannerı yok.');
    }

    const embed = new EmbedBuilder()
      .setTitle(`${user.tag} kullanıcısının bannerı`)
      .setImage(banner)
      .setColor('#0099ff');

    await message.reply({ embeds: [embed] });
  },
};
