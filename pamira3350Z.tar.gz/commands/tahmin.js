import db from 'croxydb';
import { EmbedBuilder } from 'discord.js';

function drawHangman(attempts) {
    const stages = [
        '```plaintext\n' +
        ' +---+\n' +
        ' |   |\n' +
        '     |\n' +
        '     |\n' +
        '     |\n' +
        '     |\n' +
        '=========\n```',

        '```plaintext\n' +
        ' +---+\n' +
        ' |   |\n' +
        ' O   |\n' +
        '     |\n' +
        '     |\n' +
        '     |\n' +
        '=========\n```',

        '```plaintext\n' +
        ' +---+\n' +
        ' |   |\n' +
        ' O   |\n' +
        ' |   |\n' +
        '     |\n' +
        '     |\n' +
        '=========\n```',

        '```plaintext\n' +
        ' +---+\n' +
        ' |   |\n' +
        ' O   |\n' +
        ' |   |\n' +
        ' /    |\n' +
        '     |\n' +
        '=========\n```',

        '```plaintext\n' +
        ' +---+\n' +
        ' |   |\n' +
        ' O   |\n' +
        ' |   |\n' +
        ' / \\  |\n' +
        '     |\n' +
        '=========\n```',

        '```plaintext\n' +
        ' +---+\n' +
        ' |   |\n' +
        ' O   |\n' +
        ' |   |\n' +
        ' / \\  |\n' +
        '     |\n' +
        '=========\n```',

        '```plaintext\n' +
        ' +---+\n' +
        ' |   |\n' +
        ' O   |\n' +
        ' |   |\n' +
        ' / \\  |\n' +
        '     |\n' +
        '=========\n```'
    ];

    return stages[6 - attempts];
}

export default {
    name: 'tahmin',
    description: 'Adamasmaca oyununda tahmin yapar.',
    execute: async (message, args) => {
        const userId = message.author.id;
        const letter = args[0]?.toLowerCase();

        if (!letter || letter.length !== 1) {
            return message.reply('Lütfen tek bir harf tahmin edin.');
        }

        const game = db.get(`adamasmaca_${userId}`);
        if (!game) {
            return message.reply('Önce adamasmaca oyunu başlatmalısınız.');
        }

        let { word, masked, attempts, guessedLetters } = game;

        if (guessedLetters.includes(letter)) {
            return message.reply('Bu harfi zaten tahmin ettiniz.');
        }

        guessedLetters.push(letter);

        // Doğru tahmin edilen harfleri gizli kelimede açma işlemi
        let newMasked = '';
        for (let i = 0; i < word.length; i++) {
            if (word[i] === letter) {
                newMasked += letter;
            } else {
                newMasked += masked[i];
            }
        }

        masked = newMasked;
        db.set(`adamasmaca_${userId}`, { word, masked, attempts, guessedLetters });

        if (masked === word) {
            db.delete(`adamasmaca_${userId}`);
            const winEmbed = new EmbedBuilder()
                .setTitle('Tebrikler!')
                .setDescription(`Kelimeyi doğru tahmin ettiniz: **${word}**`)
                .setColor('#00ff00');
            return message.reply({ embeds: [winEmbed] });
        }

        if (word.includes(letter)) {
            const correctGuessEmbed = new EmbedBuilder()
                .setTitle('Doğru Tahmin!')
                .setDescription(`Gizli kelime: **${masked}**`)
                .setColor('#00ff00');
            return message.reply({ embeds: [correctGuessEmbed] });
        } else {
            attempts--;
            db.set(`adamasmaca_${userId}`, { word, masked, attempts, guessedLetters });

            if (attempts <= 0) {
                db.delete(`adamasmaca_${userId}`);
                const loseEmbed = new EmbedBuilder()
                    .setTitle('Oyunu Kaybettiniz!')
                    .setDescription(`Gizli kelime: **${word}**`)
                    .setColor('#ff0000');
                return message.reply({ embeds: [loseEmbed] });
            }

            const hangmanEmbed = new EmbedBuilder()
                .setTitle('Yanlış Tahmin!')
                .setDescription(`${drawHangman(attempts)}\nKalan deneme sayınız: **${attempts}**\nGizli kelime: **${masked}**`)
                .setColor('#ff0000');
            return message.reply({ embeds: [hangmanEmbed] });
        }
    },
};
