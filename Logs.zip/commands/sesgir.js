import { joinVoiceChannel, VoiceConnectionStatus } from '@discordjs/voice';
import fs from 'fs';
import path from 'path';

// JSON dosyasını oku
const configPath = path.resolve('config.json');
const config = JSON.parse(fs.readFileSync(configPath, 'utf-8'));

export default {
  name: 'ses-gir',
  description: 'Bot belirtilen ses kanalına girer ve ardından çıkar.',
  async execute(message, args) {
    if (message.author.id !== config.ownerid) {
      return message.reply('Bu komutu kullanma yetkiniz yok.');
    }

    const channelId = args[0];
    if (!channelId) {
      return message.reply('Lütfen bir ses kanalının ID\'sini belirtin.');
    }

    const channel = message.guild.channels.cache.get(channelId);

    if (!channel) {
      return message.reply('Bu ID ile bir kanal bulunamadı.');
    }

    if (channel.type !== 2) { // 2: GUILD_VOICE
      return message.reply('Geçerli bir ses kanalı ID\'sini belirtin.');
    }

    const connection = joinVoiceChannel({
      channelId: channel.id,
      guildId: message.guild.id,
      adapterCreator: message.guild.voiceAdapterCreator,
    });

    connection.on(VoiceConnectionStatus.Ready, () => {
      console.log('Ses kanalına başarıyla katıldım!');
      message.reply('Başarıyla ses kanalına katıldım!');
      connection.destroy();
    });

    connection.on(VoiceConnectionStatus.Disconnected, () => {
      console.log('Ses kanalından ayrıldım.');
      message.reply('Ses kanalından ayrıldım.');
    });
  },
};
