import { EmbedBuilder, GatewayIntentBits } from 'discord.js';

export default {
    name: 'userinfo',
    description: 'Kullanıcı bilgilerini gösterir.',
    async execute(message, args) {
        // Kullanıcıyı belirleme
        const user = message.mentions.users.first() || message.author;

        // Kullanıcı bilgilerini oluşturun
        const member = message.guild.members.cache.get(user.id);
        const username = user.username;
        const tag = user.tag;
        const id = user.id;
        const createdAt = user.createdAt.toDateString();
        const joinedAt = member ? member.joinedAt.toDateString() : 'Bu sunucuda değil';

        // Kullanıcının durumu
        let status;
        if (member && member.presence && member.presence.status) {
            switch (member.presence.status) {
                case 'online':
                    status = 'Aktif';
                    break;
                case 'idle':
                    status = 'Boşta';
                    break;
                case 'dnd':
                    status = 'Rahatsız Etmeyin';
                    break;
                case 'offline':
                    status = 'Görünmüyor';
                    break;
                default:
                    status = 'Bilinmiyor';
                    break;
            }
        } else {
            status = 'Bilinmiyor';
        }

        const avatarURL = user.displayAvatarURL({ size: 2048, dynamic: true });

        // Kullanıcı bilgilerini içeren embed oluşturun
        const embed = new EmbedBuilder()
            .setColor('#00A86B') // Discord yeşil rengi
            .setTitle(`${username} Kullanıcı Bilgileri`)
            .setThumbnail(avatarURL) // Kullanıcı avatarı
            .addFields(
                { name: '👤 Kullanıcı Adı', value: username, inline: true },
                { name: '✉️ Etiket', value: tag, inline: true },
                { name: '🆔 Kullanıcı ID', value: id, inline: true },
                { name: '📅 Hesap Oluşturulma Tarihi', value: createdAt, inline: true },
                { name: '📅 Sunucuya Katılma Tarihi', value: joinedAt, inline: true },
                { name: '🟢 Durum', value: status, inline: true }
            )
            .setFooter({ text: `Bilgi istendi` })
            .setTimestamp();

        // Mesajı yanıtla
        await message.channel.send({ embeds: [embed] });
    }
};
