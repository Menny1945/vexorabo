import Canvas from 'canvas';
import { AttachmentBuilder } from 'discord.js';
import fetch from 'node-fetch';
import db from 'croxydb';
import fs from 'fs';
import path from 'path';
import sharp from 'sharp';

// __dirname yerine import.meta.url ile dinamik yol oluşturma
const __dirname = new URL('.', import.meta.url).pathname;

export default {
  name: 'guildMemberRemove',
  async execute(member, client) {
    console.log(`${member.user.tag} sunucudan ayrıldı.`);

    const logChannelId = db.get(`logChannel_${member.guild.id}`);
    if (!logChannelId) {
      console.log('Log kanalı ayarlanmamış.');
      return;
    }

    const channel = member.guild.channels.cache.get(logChannelId);
    if (!channel) {
      console.log('Log kanalı bulunamadı.');
      return;
    }

    try {
      // Avatar URL'sini al
      const avatarURL = member.user.displayAvatarURL({ format: 'png', size: 1024 });
      console.log('Avatar URL:', avatarURL); // URL'yi kontrol et

      // Avatarı yükle ve PNG formatına dönüştür
      const responseAvatar = await fetch(avatarURL);
      if (!responseAvatar.ok) throw new Error('Avatar yüklenemedi'); // Yanıtı kontrol et

      const arrayBufferAvatar = await responseAvatar.arrayBuffer();
      const bufferAvatar = Buffer.from(arrayBufferAvatar);
      const pngBufferAvatar = await sharp(bufferAvatar).toFormat('png').toBuffer();

      // Yerel dosya yolu
      const imagePath = path.join(__dirname, '../selam.png');
      if (!fs.existsSync(imagePath)) throw new Error('Görsel dosyası bulunamadı'); // Dosya varlığını kontrol et

      const localImageBuffer = fs.readFileSync(imagePath);

      // Canvas oluştur
      const canvas = Canvas.createCanvas(700, 250);
      const ctx = canvas.getContext('2d');

      // Arka plan görselini yükle
      const background = await Canvas.loadImage(localImageBuffer);
      ctx.drawImage(background, 0, 0, canvas.width, canvas.height);

      // Avatarı daire içine çiz
      const avatar = await Canvas.loadImage(pngBufferAvatar);
      const avatarSize = 200;
      const avatarX = (canvas.width - avatarSize) / 2;
      const avatarY = (canvas.height - avatarSize) / 2 + 20; // Avatarı yukarıya doğru kaydırdık

      // Daire şeklinde klip oluştur
      ctx.save();
      ctx.beginPath();
      ctx.arc(canvas.width / 2, canvas.height / 2 - 20, avatarSize / 2, 0, Math.PI * 2, true); // Yüksekliği yukarı çek
      ctx.closePath();
      ctx.clip();
      ctx.drawImage(avatar, avatarX, avatarY, avatarSize, avatarSize);
      ctx.restore();

      // Metin ekle
      ctx.font = '28px sans-serif';
      ctx.fillStyle = '#ffffff';
      ctx.textAlign = 'center';
      ctx.fillText('Güle güle', canvas.width / 2, 50); // Metni yukarı taşı

      ctx.font = '22px sans-serif';
      ctx.fillText(`${member.user.tag}`, canvas.width / 2, 180);

      // Dosyayı oluştur ve kanala gönder
      const attachment = new AttachmentBuilder(canvas.toBuffer(), { name: 'goodbye-image.png' });
      await channel.send({ content: `Güle güle ${member.user}`, files: [attachment] });
    } catch (error) {
      console.error('Resim işlenirken bir hata oluştu:', error);
    }
  },
};
