import { PermissionsBitField, EmbedBuilder } from 'discord.js';
import db from 'croxydb';

export default {
  name: 'ayarlar',
  description: 'Sunucudaki otomatik işlemleri gösterir.',
  async execute(message) {
    if (!message.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
      return message.reply('Bu komutu kullanmak için gerekli izinlere sahip değilsiniz.');
    }

    // Hoşgeldin/Güle Güle log kanalı kontrolü
    const logChannelId = db.get(`logChannel_${message.guild.id}`);
    let hgbbStatus;

    if (logChannelId) {
      const logChannel = message.guild.channels.cache.get(logChannelId);
      hgbbStatus = `<:rickbottik:1277255912393806008> Aktif. Log kanalı: ${logChannel}\nKapatmak için: \`.hgbb kapat\``;
    } else {
      hgbbStatus = `<:rickbotx:1277255857599545426> Aktif değil. Aktif etmek için: \`.hgbb aç #kanal\``;
    }

    // Embed oluşturma
    const settingsEmbed = new EmbedBuilder()
      .setTitle(`${message.guild.name} - Sunucu Ayarları`)
      .setColor(0x00AE86)
      .addFields(
        { name: 'Hoşgeldin/Güle Güle Log Kanalı', value: hgbbStatus },
        // Buraya diğer otomatik işlemleri ekleyebilirsiniz
      )
      .setTimestamp();

    message.channel.send({ embeds: [settingsEmbed] });
  },
};
