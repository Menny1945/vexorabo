import { PermissionsBitField } from 'discord.js';

export default {
  name: 'rolal',
  description: 'Bir kullanıcıdan rol alır.',
  async execute(message, args) {
    if (!message.member.permissions.has(PermissionsBitField.Flags.ManageRoles)) {
      return message.reply('Bu komutu kullanmak için yeterli izniniz yok.');
    }

    if (args.length < 2) {
      return message.reply('Lütfen bir kullanıcı ve rol belirtin. Örnek kullanım: !rolal @kullanıcı @rol');
    }

    const user = message.mentions.users.first();
    const role = message.mentions.roles.first();

    if (!user || !role) {
      return message.reply('Lütfen geçerli bir kullanıcı ve rol belirtin.');
    }

    const member = message.guild.members.cache.get(user.id);
    const botMember = message.guild.members.cache.get(message.client.user.id);

    if (botMember.roles.highest.position <= role.position) {
      return message.reply('Botun rolü, bu rolün üstünde değil. Rolü alamazsınız.');
    }

    await member.roles.remove(role.id);

    message.reply(`${user.tag} kullanıcısından ${role.name} rolü alındı.`);
  },
};
