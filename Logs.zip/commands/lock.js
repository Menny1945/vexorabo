import { PermissionsBitField } from 'discord.js';

export default {
    name: 'lock',
    description: 'Kanalı kilitler ve yetkisi olmayan kullanıcıların mesaj atmasını engeller.',
    execute: async (message, args) => {
        if (!message.member.permissions.has(PermissionsBitField.Flags.ManageChannels)) {
            return message.reply('Bu komutu kullanmak için **Kanalları Yönet** yetkisine sahip olmalısın.');
        }

        const channel = message.mentions.channels.first() || message.channel;

        try {
            await channel.permissionOverwrites.edit(message.guild.roles.everyone, {
                SendMessages: false,
            });

            await message.reply(`🔒 ${channel.name} kanalı başarıyla kilitlendi. Sadece yetkili kişiler mesaj atabilir.`);
        } catch (error) {
            console.error('Kanalı kilitleme sırasında bir hata oluştu:', error);
            await message.reply('Kanalı kilitlemeye çalışırken bir hata oluştu.');
        }
    },
};
