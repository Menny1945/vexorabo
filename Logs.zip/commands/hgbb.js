import { PermissionsBitField } from 'discord.js';
import db from 'croxydb';

export default {
  name: 'hgbb',
  async execute(message, args) {
    if (!message.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
      return message.reply('Bu komutu kullanmak için gerekli izinlere sahip değilsiniz.');
    }

    const subCommand = args[0];
    const logChannel = message.mentions.channels.first();

    if (!subCommand || !logChannel) {
      return message.reply('Geçersiz kullanım. Doğru kullanım: `hgbb [aç/kapat] #kanal`');
    }

    if (subCommand === 'aç') {
      db.set(`logChannel_${message.guild.id}`, logChannel.id);
      return message.reply(`Hoşgeldin/Güle Güle log kanalı olarak ${logChannel} ayarlandı.`);
    } else if (subCommand === 'kapat') {
      db.delete(`logChannel_${message.guild.id}`);
      return message.reply('Hoşgeldin/Güle Güle log kanalı kapatıldı.');
    } else {
      return message.reply('Geçersiz alt komut. Kullanılabilir alt komutlar: `aç`, `kapat`.');
    }
  },
};
