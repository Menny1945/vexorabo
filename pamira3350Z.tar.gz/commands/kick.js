import { PermissionsBitField, EmbedBuilder, Colors } from 'discord.js';

export default {
  name: 'kick',
  description: 'Belirtilen kullanıcıyı sunucudan atar.',
  async execute(message, args) {
    // Sunucunun sahibi kontrolü
    const isServerOwner = message.guild.ownerId === message.author.id;

    // Yetki kontrolü
    if (!isServerOwner && !message.member.permissions.has(PermissionsBitField.Flags.KickMembers)) {
      return message.reply('🚫 Bu komutu kullanmak için yeterli yetkiye sahip değilsiniz.');
    }

    const user = message.mentions.users.first();
    if (!user) {
      return message.reply('⚠️ Lütfen atmak için bir kullanıcı belirtin.');
    }

    const member = message.guild.members.cache.get(user.id);
    if (!member) {
      return message.reply('⚠️ Bu kullanıcı sunucuda bulunmuyor.');
    }

    // Yetki kontrolü
    if (!isServerOwner) {
      if (member.roles.highest.position >= message.member.roles.highest.position) {
        return message.reply('🚫 Kendinizden üstteki birini atamazsınız.');
      }

      if (member.roles.highest.position >= message.guild.members.me.roles.highest.position) {
        return message.reply('🚫 Bu kullanıcıyı atamam çünkü onun rolü benim rolümden üstün.');
      }
    }

    const reason = args.slice(1).join(' ') || 'Neden belirtilmemiş';

    try {
      await member.kick(reason);

      const embed = new EmbedBuilder()
        .setColor(Colors.Green)
        .setTitle('🔨 Kullanıcı Atıldı')
        .setDescription(`${user.tag} başarıyla sunucudan atıldı.`)
        .addFields(
          { name: 'Sebep', value: reason, inline: true },
          { name: 'Atan Kişi', value: message.author.tag, inline: true }
        )
        .setTimestamp()
        .setFooter({ text: 'Kick Komutu' });

      await message.reply({ embeds: [embed] });
    } catch (error) {
      console.error(error);
      await message.reply('⚠️ Kullanıcıyı atarken bir hata oluştu.');
    }
  },
};
