// commands/zaman.js
import { EmbedBuilder } from 'discord.js';
import moment from 'moment';

export default {
  name: 'zaman',
  description: 'Belirli bir tarih ve saat için <t::t> formatında bir takvim hatırlatıcısı oluşturur.',
  async execute(message, args) {
    if (args.length < 2) {
      return message.reply('Lütfen geçerli bir tarih ve saat formatı sağlayın. Örnek: `.zaman 28.05.2025 00:00`');
    }

    const [dateStr, timeStr] = args.join(' ').split(' ');
    const dateTimeStr = `${dateStr} ${timeStr}`;

    // Tarih ve saati kontrol et
    const dateTime = moment(dateTimeStr, 'DD.MM.YYYY HH:mm');
    if (!dateTime.isValid()) {
      return message.reply('Lütfen geçerli bir tarih ve saat formatı kullanın. Örnek: `28.05.2025 00:00`');
    }

    // Discord takvim formatına dönüştür
    const calendarFormat = `<t:${Math.floor(dateTime.valueOf() / 1000)}:f>`;

    // Embed oluştur
    const embed = new EmbedBuilder()
      .setColor('#00FF00')
      .setTitle('Zamanlayıcı Ayarlandı')
      .setDescription(`Belirlenen tarih ve saat: ${calendarFormat}`)
      .setTimestamp();

    await message.channel.send({ embeds: [embed] });
  },
};
