import { AttachmentBuilder } from 'discord.js';
import QRCode from 'qrcode';

export default {
  name: 'qrcode',
  description: 'Generates a QR code for the provided text.',
  async execute(message, args) {
    if (args.length === 0) {
      return message.reply('Please provide text to generate a QR code.');
    }

    const text = args.join(' ');

    try {
      const qrCodeImage = await QRCode.toBuffer(text);
      const attachment = new AttachmentBuilder(qrCodeImage, { name: 'qrcode.png' });
      await message.channel.send({ content: 'Here is your QR code:', files: [attachment] });
    } catch (error) {
      console.error('Error generating QR code:', error);
      message.reply('There was an error generating the QR code.');
    }
  },
};
