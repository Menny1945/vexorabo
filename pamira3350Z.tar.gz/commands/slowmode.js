import { PermissionsBitField, ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder } from 'discord.js';

export default {
  name: 'slowmode',
  description: 'Ayarlanan kanalda yavaş mod süresini ayarlar.',
  async execute(message, args) {
    // Botun gerekli izni kontrol et
    if (!message.member.permissions.has(PermissionsBitField.Flags.ManageChannels)) {
      return message.reply('Bu komutu kullanmak için gerekli izinlere sahip değilsiniz.');
    }

    // Komut argümanlarını al
    const channel = message.mentions.channels.first();
    const seconds = parseInt(args[1]);

    if (!channel || isNaN(seconds)) {
      return message.reply('Lütfen geçerli bir kanal ve süre belirtin.');
    }

    // Süreyi 6 saat ile sınırlama
    if (seconds < 0 || seconds > 21600) {
      return message.reply('Yavaş mod süresi 0 ile 21600 saniye arasında olmalıdır.');
    }

    // Yavaş mod süresini ayarla
    try {
      await channel.setRateLimitPerUser(seconds);
      const embed = new EmbedBuilder()
        .setColor('Green')
        .setTitle('Yavaş Mod Ayarlandı')
        .setDescription(`Kanal ${channel} için yazma süresi **${seconds}** saniye olarak ayarlandı.`);
      message.reply({ embeds: [embed] });
    } catch (error) {
      console.error(error);
      message.reply('Bir hata oluştu, lütfen tekrar deneyin.');
    }
  },
};
