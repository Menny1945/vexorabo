import { EmbedBuilder } from 'discord.js';

export default {
    name: 'snipe',
    description: 'Son silinen mesajı gösterir.',
    execute: async (message) => {
        const { client, channel } = message;

        // Son silinen mesajı tutmak için bir değişken oluşturuyoruz
        const snipedMessage = client.snipes?.get(channel.id);
        
        if (!snipedMessage) {
            return message.channel.send('Bu kanalda silinen bir mesaj bulunamadı.');
        }

        const { content, author, createdAt } = snipedMessage;

        const embed = new EmbedBuilder()
            .setAuthor({ name: author.tag, iconURL: author.displayAvatarURL({ dynamic: true }) })
            .setDescription(content)
            .setColor('Random')
            .setFooter({ text: `Atıldığı tarih: ${createdAt}` })
            .setTimestamp();

        message.channel.send({ embeds: [embed] });
    },
};

// Botun "messageDelete" eventini yakalaması ve silinen mesajı kaydetmesi gerekiyor:
export const handleDelete = (message) => {
    if (!message.guild || message.author.bot) return;

    message.client.snipes = message.client.snipes || new Map();
    message.client.snipes.set(message.channel.id, {
        content: message.content,
        author: message.author,
        createdAt: message.createdAt,
    });
};
