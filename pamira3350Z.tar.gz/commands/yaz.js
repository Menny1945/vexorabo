export default {
    name: 'yaz',
    description: 'Belirtilen mesajı botun yazmasını sağlar.',
    execute: async (message, args) => {
        // Eğer bir mesaj girilmediyse uyarı ver
        if (!args.length) {
            return message.reply('Lütfen yazmamı istediğin mesajı belirt.');
        }

        // Komutun kendisini ve argümanları temizleyip birleştiriyoruz
        const sayMessage = args.join(' ');

        try {
            // Komutu kullanan kişinin mesajını sil
            await message.delete();

            // Bot belirtilen mesajı gönderir
            await message.channel.send(sayMessage);
        } catch (error) {
            console.error('Mesaj yazılırken bir hata oluştu:', error);
            await message.reply('Mesajı yazmaya çalışırken bir hata oluştu.');
        }
    },
};
