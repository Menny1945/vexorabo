export default {
    name: 'messageDelete',
    once: false, // Bu event sürekli olarak dinlenmeli, sadece bir kere değil
    execute: (message) => {
        // Botun mesajını veya DM mesajlarını işleme
        if (!message.guild || message.author.bot) return;

        // Silinen mesajları saklamak için bir Map kullanıyoruz
        message.client.snipes = message.client.snipes || new Map();

        // Kanal ID'siyle birlikte silinen mesajı Map'e kaydediyoruz
        message.client.snipes.set(message.channel.id, {
            content: message.content,
            author: message.author,
            createdAt: message.createdAt,
            image: message.attachments.first()?.proxyURL || null, // Eğer mesajda resim varsa, bunu da ekliyoruz
        });
    },
};
