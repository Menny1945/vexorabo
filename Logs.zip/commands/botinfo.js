import { version } from 'discord.js';
import os from 'os';
import moment from 'moment';
import { EmbedBuilder } from 'discord.js';

export default {
  name: 'botinfo',
  description: 'Bot hakkında bilgi verir.',
  async execute(message, args) {
    // Shard'lardan verileri toplayın
    const shardInfo = await message.client.shard.broadcastEval(() => ({
      guildCount: this.guilds.cache.size,
      userCount: this.users.cache.size,
      memoryUsage: (process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2),
      uptime: this.uptime,
      ping: this.ws.ping,
    }));

    // Verileri birleştir
    const totalGuilds = shardInfo.reduce((acc, shard) => acc + shard.guildCount, 0);
    const totalUsers = shardInfo.reduce((acc, shard) => acc + shard.userCount, 0);
    const totalMemory = shardInfo.reduce((acc, shard) => acc + parseFloat(shard.memoryUsage), 0).toFixed(2);
    const totalUptime = shardInfo.reduce((acc, shard) => acc + shard.uptime, 0);
    const averagePing = (shardInfo.reduce((acc, shard) => acc + shard.ping, 0) / shardInfo.length).toFixed(2);

    // Bot çalışma süresini daha okunabilir hale getirme
    const humanizedUptime = moment.duration(totalUptime).humanize();

    // İşletim sistemi bilgisi
    const platform = os.platform();
    const architecture = os.arch();

    // Bot adı ve ID'si
    const botName = message.client.user.tag;
    const botID = message.client.user.id;

    // Botun sahibi hakkında bilgi
    const owner = 'Rick V25'; // Bot sahibinin bilgisi

    // Embed mesajı oluştur
    const embed = new EmbedBuilder()
      .setColor('#7289DA')
      .setTitle('👾 Bot Bilgileri 👾')
      .addFields(
        { name: '🎮 Bot Adı', value: `🎱 ${botName}`, inline: true },
        { name: '💾 Bot ID', value: `📡 ${botID}`, inline: true },
        { name: '👨‍💻 Geliştirici', value: `🔧 ${owner}`, inline: true },
        { name: '🛠️ Discord.js Versiyonu', value: `📜 v${version}`, inline: true },
        { name: '📦 Node.js Versiyonu', value: `🗂️ ${process.version}`, inline: true },
        { name: '🖥️ Platform', value: `🛡️ ${platform} (${architecture})`, inline: true },
        { name: '🌐 Sunucu Sayısı', value: `🏢 ${totalGuilds}`, inline: true },
        { name: '👥 Kullanıcı Sayısı', value: `🔗 ${totalUsers}`, inline: true },
        { name: '🚀 Ortalama Gecikme Süresi', value: `⚡ ${averagePing}ms`, inline: true },
        { name: '💾 Bellek Kullanımı', value: `📂 ${totalMemory} MB`, inline: true },
        { name: '⏳ Çalışma Süresi', value: `🕒 ${humanizedUptime}`, inline: true }
      )
      .setTimestamp()
      .setFooter({ text: `🤖 ${botName} tarafından`, iconURL: message.client.user.displayAvatarURL() });

    // Embed mesajını gönder
    message.channel.send({ embeds: [embed] });
  },
};
