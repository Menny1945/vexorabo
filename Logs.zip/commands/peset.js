import db from 'croxydb';
import { EmbedBuilder } from 'discord.js';

export default {
    name: 'peset',
    description: 'Adamasmaca oyununu bitirir.',
    execute: async (message) => {
        const userId = message.author.id;
        const game = db.get(`adamasmaca_${userId}`);

        if (!game) {
            return message.reply('Aktif bir Adamasmaca oyunu bulunmuyor.');
        }

        db.delete(`adamasmaca_${userId}`);

        const embed = new EmbedBuilder()
            .setTitle('Oyun Sonlandırıldı')
            .setDescription('Oyunu pes ettiniz. Yeni bir oyun başlatabilirsiniz.')
            .setColor('#ff0000');

        return message.reply({ embeds: [embed] });
    },
};
