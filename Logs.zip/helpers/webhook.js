import fetch from 'node-fetch';
import dotenv from 'dotenv';

dotenv.config();

const webhookURL = process.env.WEBHOOK_URL;

export async function sendWebhookMessage(message) {
  if (!webhookURL) {
    console.error('Webhook URL tanımlı değil.');
    return;
  }

  try {
    await fetch(webhookURL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ content: message }),
    });
  } catch (error) {
    console.error('Webhook mesajı gönderilirken hata oluştu:', error);
  }
}
