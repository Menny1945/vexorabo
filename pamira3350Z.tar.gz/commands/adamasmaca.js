import db from 'croxydb';
import { EmbedBuilder, ButtonBuilder, ButtonStyle, ActionRowBuilder } from 'discord.js';

export default {
    name: 'adamasmaca',
    description: 'Adamasmaca oyununu başlatır.',
    execute: async (message) => {
        const userId = message.author.id;

        // Veriyi güvenli bir şekilde get etme
        let activeGame;
        try {
            activeGame = db.get(`adamasmaca_${userId}`);
        } catch (error) {
            console.error('JSON verisi alınırken bir hata oluştu:', error);
            return message.reply('Veritabanından oyun verisi alınırken bir hata oluştu.');
        }

        if (activeGame) {
            return message.reply('Zaten bir Adamasmaca oyunu oynuyorsunuz. Önce mevcut oyunu bitirin.');
        }

        const words = ['kelime', 'bot', 'program', 'discord', 'yazılım'];
        const randomWord = words[Math.floor(Math.random() * words.length)];
        const maskedWord = '-'.repeat(randomWord.length);

        // Veriyi güvenli bir şekilde set etme
        try {
            db.set(`adamasmaca_${userId}`, {
                word: randomWord,
                masked: maskedWord,
                attempts: 6,
                guessedLetters: []
            });
        } catch (error) {
            console.error('JSON verisi set edilirken bir hata oluştu:', error);
            return message.reply('Oyun verisi kaydedilirken bir hata oluştu.');
        }

        const embed = new EmbedBuilder()
            .setTitle('Adamasmaca Oyunu Başladı!')
            .setDescription(`Tahmin etmeniz gereken kelime: ${maskedWord} (Kelime uzunluğu: ${randomWord.length} harf)\n\n**Nasıl Oynanır?**\n- Tahmin etmek istediğiniz harfleri yazın.\n- Her yanlış tahminde, kalan tahmin hakkınız azalır.\n- Doğru tahminleriniz kelimenin açık olan harflerini günceller.\n- Kalan tahmin hakkınız sıfır olduğunda oyun biter.\n\n**Pes Etmek İçin**\n- Oyun sırasında pes etmek isterseniz, "Pes Et" butonuna basabilirsiniz veya .peset yazabilirsiniz.`)
            .setColor('#0099ff');

        const button = new ButtonBuilder()
            .setCustomId('pesEt')
            .setLabel('Pes Et')
            .setStyle(ButtonStyle.Danger);

        const actionRow = new ActionRowBuilder().addComponents(button);

        try {
            await message.reply({ embeds: [embed], components: [actionRow] });
        } catch (error) {
            console.error('Adamasmaca oyununu başlatırken bir hata oluştu:', error);
            await message.reply('Adamasmaca oyununu başlatırken bir hata oluştu.');
        }
    },
};
